╭────────────────────────────────────────╮
│                      🚀 Why I Built This Module             │
╰────────────────────────────────────────╯

I noticed a lot of people either selling leaked keyboxes or paying
for modules that claim to pass **strong Play Integrity** but only offer
leaked keyboxes. I created this module to give you **real**, 
**working keyboxes** completely **free**, no hidden charges, no scams,
just **legit access** with several useful features 🚫🔑


╭────────────────────────────────────────╮
│                   ✅ Module Features                        │
╰────────────────────────────────────────╯

- ✅ Updates `keybox.xml`  
- 🗽 Updates `target.txt` as per your TEE status  
- 🥷 Switch Shamiko modes (via module toggle)  
- 🛠️ Adds all custom ROM detection packages in the **SusFS path**  
- ⛔ Disables EU injector by default  
- ⛔ Disables Pixel ROM spoofing  
- 🔐 Spoofs encryption status  
- 🎭 Hides LSPosed logs  
- 🔑 Spoofs ROM release key  
- ⚙️ Updates SusFS config  
- ⚙️ Updates SusFS boot hash file  
- 🕵️ Detects abnormal activity to help debug issues  
- 🎨 More features are available smash the Action/WebUI button  


╭────────────────────────────────────────╮
│               🗽 Required Modules. (Pre-Install)              │
╰────────────────────────────────────────╯

- **Play Integrity Fork**  
  https://github.com/osm0sis/PlayIntegrityFork/releases

- **Tricky Store**  
  https://github.com/5ec1cff/TrickyStore/releases


╭────────────────────────────────────────╮
│                      🐞 Troubleshooting.                     │
╰────────────────────────────────────────╯

> Can't grant root access to apps via Magisk?

  Create a `stop` file in internal storage (`/sdcard`) to disable  
  auto whitelist, or disable this module to switch Shamiko to  
  blacklist mode (unhides root).

> Play Integrity still failing?  

  Hide root properly. If using a custom ROM, disable the built-in  
  GMS spoofing. How? Ask in your ROM’s support group  (varies by ROM)