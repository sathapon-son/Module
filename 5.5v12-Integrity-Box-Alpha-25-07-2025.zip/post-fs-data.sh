#!/system/bin/sh
L="/data/adb/Integrity-Box-Logs/post.log"
MODULE="/data/adb/modules"
MODDIR="$MODULE/integrity_box"
SRC="$MODULE/integrity_box/sus.sh"
DEST_FILE="$SUSFS/action.sh"
PIF="$MODULE/playintegrityfix"
SHAMIKO="$MODULE/zygisk_shamiko"
NOHELLO="$MODULE/zygisk_nohello"
TRICKY_STORE="$MODULE/tricky_store"
SUSFS="$MODULE/susfs4ksu"
BNR="/data/adb/modules/AOSP_Dialer/module.prop"

log() { echo -e "$1" | tee -a "$L"; }

if [ -e /data/adb/modules/integrity_box/disable ]; then
    rm -rf /data/adb/modules/integrity_box/disable
    log "Module re-enabled successfully"
else
    log "Status 1"
fi

if [ -e /data/adb/shamiko/whitelist ]; then
    rm -rf /data/adb/shamiko/whitelist
    log "Nuked whitelist to avoid bootloop"
else
    log "Status 2"
fi

if [ -e /data/adb/modules/Integrity-Box]; then
    rm -rf /data/adb/modules/Integrity-Box
    log "Nuked old integrity box module"
else
    log "Status 3"
fi

if [ -f "$BNR" ]; then
    sed -i '/^banner=/d' "$BNR"
    log " Status 5"
fi
