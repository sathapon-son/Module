# Don't flash in recovery!
if ! $BOOTMODE; then
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Recovery sucks"
    ui_print "! Please install from Magisk / KernelSU / APatch app"
    abort    "*********************************************************"
fi

# Error on < Android 8
if [ "$API" -lt 26 ]; then
    abort "! You can't use this module on Android < 8.0"
fi

check_zygisk() {
    local ZYGISK_MODULE="/data/adb/modules/zygisksu"
    local REZYGISK_MODULE="/data/adb/modules/rezygisk"
    local MAGISK_DIR="/data/adb/magisk"
    local ZYGISK_MSG="Zygisk is not enabled. Please either:
    - Enable Zygisk in Magisk settings
    - Install ZygiskNext or ReZygisk module"

    # Check if Zygisk module directory exists
    if [ -d "$ZYGISK_MODULE" ] || [ -d "$REZYGISK_MODULE" ]; then
        return 0
    fi

    # If Magisk is installed, check Zygisk settings
    if [ -d "$MAGISK_DIR" ]; then
        # Query Zygisk status from Magisk database
        local ZYGISK_STATUS
        ZYGISK_STATUS=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';")

        # Check if Zygisk is disabled
        if [ "$ZYGISK_STATUS" = "value=0" ]; then
            abort "$ZYGISK_MSG"
        fi
    else
        abort "$ZYGISK_MSG"
    fi
}

# Module requires Zygisk to work
check_zygisk

# safetynet-fix module is obsolete and it's incompatible with PIF
SNFix="/data/adb/modules/safetynet-fix"
if [ -d "$SNFix" ]; then
    ui_print "! safetynet-fix module is obsolete and it's incompatible with PIF, it will be removed on next reboot"
    ui_print "! Do not install it"
    touch "$SNFix"/remove
fi

# playcurl warn
if [ -d "/data/adb/modules/playcurl" ]; then
    ui_print "! playcurl may overwrite fingerprint with invalid one, be careful!"
fi

# MagiskHidePropsConf module is obsolete in Android 8+ but it shouldn't give issues
if [ -d "/data/adb/modules/MagiskHidePropsConf" ]; then
    ui_print "! WARNING, MagiskHidePropsConf module may cause issues with PIF."
fi

# Check custom fingerprint
if [ -f "/data/adb/pif.json" ]; then
    ui_print "- Backup custom pif.json"
    mv -f /data/adb/pif.json /data/adb/pif.json.old
fi

# give exec perm to autopif.sh
chmod +x "$MODPATH/autopif.sh"


# ══════════════════════════════════════

ui_print "╔════════════════════════════════════╗"
ui_print "║  ꧁𓆩🧠 𝑹𝒐𝒐𝒕 𝑷𝒉𝒂𝒏𝒕𝒐𝒎 𝑭𝑨𝑻𝑬𝑯 𓆪꧂     ║"
ui_print "║            ⟦ FATEH DZ ⟧            ║"
ui_print "║  🧠 Telegram: @ProfessorRoot_DZ     ║"
ui_print "║  🔗 Channel:  https://t.me/kernelsu1  ║"
ui_print "╚════════════════════════════════════╝"
ui_print ""

device_model=$(getprop ro.product.model)
android_version=$(getprop ro.build.version.release)
api_level=$(getprop ro.build.version.sdk)

ui_print "📱 Device: $device_model"
ui_print "📦 Android: $android_version (API $api_level)"
ui_print ""

══════════════════════════════════════

pif_integrity=$(find "$MODPATH" -type f -name "Reset.Play.Store.Services" | head -n 1)

if [ -z "$pif_integrity" ]; then
    ui_print "❌ Required file not found!"
    ui_print "  - ❌ Missing: Reset.Play.Store.Services"
    abort "❌ Aborting installation..."
fi

chmod +x "$pif_integrity"
ui_print "▶️ Executing: $pif_integrity"
"$pif_integrity" || abort "❌ Failed to run Reset.Play.Store.Services"
ui_print "✅ Reset.Play.Store.Services executed."

# ══════════════════════════════════════

nohup am start -a android.intent.action.VIEW -d "https://t.me/kernelsu1" >/dev/null 2>&1 &
ui_print "📨 Opening Telegram Channel..."