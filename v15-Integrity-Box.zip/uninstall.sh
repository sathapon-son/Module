rm -rf /data/adb/Box-Brain/Integrity-Box-Logs
rm -rf /data/adb/tricky_store/keybox.xml
rm -rf /data/adb/tricky_store/target.txt
rm -rf /data/adb/shamiko/whitelist
rm -rf /data/adb/nohello/whitelist
rm -rf /data/adb/service.d/debug.sh
rm -rf /data/adb/modules/integrity_box