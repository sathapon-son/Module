#!/system/bin/sh
nohup am start -a android.intent.action.VIEW -d https://t.me/TempMeow >/dev/null 2>&1 & 
echo "Report your problem here"
exit 0