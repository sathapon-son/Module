#!/system/bin/sh

# Module path and file references
MCTRL="${0%/*}"
SHAMIKO_WHITELIST="/data/adb/shamiko/whitelist"
NOHELLO_DIR="/data/adb/nohello"
NOHELLO_WHITELIST="$NOHELLO_DIR/whitelist"
LOG_DIR="/data/adb/Box-Brain/Integrity-Box-Logs"
LOG="$LOG_DIR/service.log"

# Logger
log() {
    echo "$1" | tee -a "$LOG"
}

# Check for Magisk presence
is_magisk() {
    [ -d /data/adb/magisk ] || getprop | grep -q 'magisk'
}

# Initial states
shamiko_prev=""
nohello_prev=""

# Loop to monitor toggle state
while true; do
  if [ -f /data/adb/Box-Brain/stop ]; then
#    log "Stop file found. Exiting background loop."
    rm -rf $SHAMIKO_WHITELIST
    rm -rf $NOHELLO_WHITELIST
    break
  fi
  
  if [ ! -e "${MCTRL}/disable" ] && [ ! -e "${MCTRL}/remove" ]; then
    if is_magisk && [ ! -f /data/adb/Box-Brain/stop ]; then

      if [ ! -f "$SHAMIKO_WHITELIST" ]; then
        touch "$SHAMIKO_WHITELIST"
      fi

      if [ -d "$NOHELLO_DIR" ] && [ ! -f "$NOHELLO_WHITELIST" ]; then
        touch "$NOHELLO_WHITELIST"
      fi

      # Show log if Shamiko just got activated
      if [ "$shamiko_prev" != "on" ] && [ -f "$SHAMIKO_WHITELIST" ]; then
        log "Shamiko Whitelist Mode Activated.✅"
        shamiko_prev="on"
      fi

      # Show log if NoHello just got activated
      if [ "$nohello_prev" != "on" ] && [ -f "$NOHELLO_WHITELIST" ]; then
        log "NoHello Whitelist Mode Activated.✅"
        nohello_prev="on"
      fi

    fi
  else
    if [ -f "$SHAMIKO_WHITELIST" ]; then
      rm -f "$SHAMIKO_WHITELIST"
      log "Shamiko Blacklist Mode Activated.❌"
      shamiko_prev="off"
    fi

    if [ -f "$NOHELLO_WHITELIST" ]; then
      rm -f "$NOHELLO_WHITELIST"
      log "NoHello Blacklist Mode Activated.❌"
      nohello_prev="off"
    fi
  fi
  sleep 4
done &

# Module install path
export MODPATH="/data/adb/modules/integrity_box"

# Remove LineageOS props (by @ez-me)
resetprop --delete ro.lineage.build.version
resetprop --delete ro.lineage.build.version.plat.rev
resetprop --delete ro.lineage.build.version.plat.sdk
resetprop --delete ro.lineage.device
resetprop --delete ro.lineage.display.version
resetprop --delete ro.lineage.releasetype
resetprop --delete ro.lineage.version
resetprop --delete ro.lineagelegal.url

# Create system.prop from build info
getprop | grep "userdebug" >> "$MODPATH/tmp.prop"
getprop | grep "test-keys" >> "$MODPATH/tmp.prop"
getprop | grep "lineage_"  >> "$MODPATH/tmp.prop"

sed -i 's///g'  "$MODPATH/tmp.prop"
sed -i 's/: /=/g' "$MODPATH/tmp.prop"
sed -i 's/userdebug/user/g' "$MODPATH/tmp.prop"
sed -i 's/test-keys/release-keys/g' "$MODPATH/tmp.prop"
sed -i 's/lineage_//g' "$MODPATH/tmp.prop"

sort -u "$MODPATH/tmp.prop" > "$MODPATH/system.prop"
rm -f "$MODPATH/tmp.prop"

sleep 30
resetprop -n --file "$MODPATH/system.prop"
