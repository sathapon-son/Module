#!/system/bin/sh

# Config 
HIZRU_GANG="/data/adb/modules/integrity_box/webroot/game/temp"
DEST_DIR="/data/adb/tricky_store"
PAGLU="keybox.xml"
ONICHAN="/data/adb/Integrity-Box-Logs/keybox_swap.log"
TEMP_FILE="/data/adb/Integrity-Box-Logs/temp_keybox.xml"

# Popup Function 
popup() {
  am start -a android.intent.action.MAIN -e mona "$@" -n popup.toast/meow.helper.MainActivity > /dev/null
  sleep 0.5
}

# Main Logic 
HIZRU=$((1 + RANDOM % 21))
HIZRU_ARMY="$HIZRU_GANG/mona($HIZRU).tar"
TIME=$(date "+%Y-%m-%d %H:%M:%S")
BKL=$(date "+%d %b %Y")

mkdir -p "$DEST_DIR"
mkdir -p "$(dirname "$ONICHAN")"

if [ -f "$HIZRU_ARMY" ]; then
  sed '$d' "$HIZRU_ARMY" > "$TEMP_FILE"

  cat >> "$TEMP_FILE" <<EOF
<IntegrityNote><![CDATA[

------------------------------------------------------------------- 
  Integrity🛡Box KEYBOX RETRIEVER      
------------------------------------------------------------------- 

|    🔑 Key Type  : Public Leak 
|    🪐 Date       : Last updated on $BKL 
|    🤖 Retriever   : Integrity Box by MEOWna 
|    🌐 Update    : https://t.me/MeowDump 
|    😋 WebPage  : https://integritybox.vercel.app
------------------------------------------------------------------- 
------------------------------------------------------------------- 

]]></IntegrityNote>
</AndroidAttestation>
EOF

  mv "$TEMP_FILE" "$DEST_DIR/$PAGLU"

  echo "$TIME ✅ mona($HIZRU)" >> "$ONICHAN"
  popup "✔️ keybox($HIZRU) used as default keybox"

else
  echo "$TIME ❌ Error: $HIZRU_ARMY not found!" >> "$ONICHAN"
  popup "❌ please use bug report button"
fi

kill_process() {
    TARGET="$1"
    PID=$(pidof "$TARGET")

    if [ -n "$PID" ]; then
    fi
}

# Kill Google Play Services (unstable)
kill_process "com.google.android.gms.unstable"

# Kill Google Play Store
kill_process "com.android.vending"