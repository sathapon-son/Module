rm -rf /data/adb/Integrity-Box-Logs
rm -rf /data/adb/tricky_store/keybox.xml
rm -rf /data/adb/tricky_store/target.txt
rm -rf /data/adb/modules/integrity_box
rm -rf /data/adb/shamiko/whitelist
rm -rf /data/adb/nohello/whitelist
pm uninstall meow.helper # Do this manually vro
pm uninstall popup.toast # Do this manually vro