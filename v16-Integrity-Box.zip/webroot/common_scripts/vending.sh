#!/system/bin/sh
su -c "pm clear com.android.vending"
su -c "pm clear com.google.android.gms"
echo " Open playstore & Check/FIX"
exit 0
