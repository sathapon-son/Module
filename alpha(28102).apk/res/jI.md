# alpha更新日志

- 如果需要使用 heapprofd（Android Heap Profiler），请关闭zygisk并重启。
- `magisk`和`su`等二进制文件不再硬编码于`/system/bin/`目录下，而是从`PATH`环境变量中选择第一个可用位置。

## Magisk (b7ca73f4-alpha)
- [App] 还原boot镜像后删除备份文件
- [App] 不主动请求权限
- [General] 保留ROOTOVL临时文件
- [App] 通过appcenter检查和下载更新
- [App] 添加遥测 https://t.me/s/magiskalpha/473
- [General] 移除addon.d支持
- [MagiskSU] 支持移除权能
- [General] 支持用户限制Root权能
- [App] 为DoH禁用SNI
- [Zygisk] 修改 libzygisk.so 名字为 heapprofd_client.so
- [General] 动态选择magisk和su等文件注入目录

# 上游更新日志

## Magisk (b62835cb) (28102)

There are a LOT of internal refactoring and significantly more testing infrastructure in the Magisk project!

- [App] Support downloading module zip files with XZ compression
- [MagiskMount] Support systemlessly deleting files with modules using blank file nodes

## Diffs to v28.1

- [App] Support downloading module zip files with XZ compression
- [MagiskMount] Support systemlessly deleting files with modules using blank file nodes
