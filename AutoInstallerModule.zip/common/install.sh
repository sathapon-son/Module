#!/system/bin/sh

MODDIR=${0%/*}
STATUS_DIR="$MODDIR/status"
mkdir -p "$STATUS_DIR"

FLAG_DONE="$STATUS_DIR/.done"
if [ -f "$FLAG_DONE" ]; then
  ui_print "✅ ติดตั้งครบทุกโมดูลแล้ว → ข้ามการทำงาน"
  exit 0
fi

ui_print "📦 Preparing download..."

# Debug path
ui_print "📁 MODDIR = $MODDIR"
ui_print "📁 STATUS_DIR = $STATUS_DIR"

# ตรวจสอบคำสั่ง curl หรือ wget
if command -v curl >/dev/null 2>&1; then
  DL="curl -L -o"
elif command -v wget >/dev/null 2>&1; then
  DL="wget -O"
else
  ui_print "❌ ไม่พบคำสั่ง curl หรือ wget"
  exit 1
fi

# ตรวจสอบ root type
ROOT_TYPE=""
if su -v 2>/dev/null | grep -iq "magisk"; then
  ROOT_TYPE="magisk"
elif su -v 2>/dev/null | grep -iq "kernelsu"; then
  ROOT_TYPE="kernelsu"
else
  ROOT_TYPE="unknown"
fi
ui_print "🔍 Root Type: $ROOT_TYPE"

# ฟังก์ชันรอจนระบบ boot เสร็จ
wait_for_boot_complete() {
  ui_print "⏳ รอ Android boot เสร็จ..."
  BOOT_COMPLETED=""
  i=0
  while [ "$BOOT_COMPLETED" != "1" ] && [ "$i" -lt 60 ]; do
    BOOT_COMPLETED=$(getprop sys.boot_completed)
    sleep 1
    i=$((i + 1))
  done
  if [ "$BOOT_COMPLETED" = "1" ]; then
    ui_print "✅ Android boot เสร็จแล้ว"
  else
    ui_print "⚠️ รอครบ 60 วิ แต่ Android ยังไม่ boot เสร็จ → ดำเนินการต่อ"
  fi
}

mkdir -p /sdcard/Root
COUNT_INSTALLED=0

while IFS="|" read -r NAME URL; do
  [ -z "$NAME" ] && continue
  [ -z "$URL" ] && continue

  ID=$(echo "$NAME" | cut -d. -f1)
  STATUS_FILE="$STATUS_DIR/$ID.installed"

  if [ -f "$STATUS_FILE" ]; then
    ui_print "✅ [$ID] $NAME - ติดตั้งแล้ว → ข้าม"
    COUNT_INSTALLED=$((COUNT_INSTALLED + 1))
    continue
  fi

  # ข้าม KsuWebUI.apk ถ้าใช้ KernelSU
  if [ "$ROOT_TYPE" = "kernelsu" ] && echo "$NAME" | grep -qi "KsuWebUI.apk"; then
    ui_print "⏭️ [$ID] ข้าม KsuWebUI.apk (ไม่จำเป็นสำหรับ KernelSU)"
    mkdir -p "$(dirname "$STATUS_FILE")"
    touch "$STATUS_FILE"
    COUNT_INSTALLED=$((COUNT_INSTALLED + 1))
    continue
  fi

  DEST="/sdcard/Root/$NAME"
  ui_print "⬇️ [$ID] กำลังดาวน์โหลด $NAME..."
  $DL "$DEST" "$URL" || {
    ui_print "❌ [$ID] ล้มเหลว: $NAME"
    continue
  }

  ui_print "📦 [$ID] ติดตั้ง $NAME..."

  if [ "${NAME##*.}" = "apk" ]; then
    TMP_APK="/data/local/tmp/$NAME"
    cp "$DEST" "$TMP_APK" || {
      ui_print "❌ [$ID] คัดลอก APK ล้มเหลว"
      continue
    }
    pm install -r "$TMP_APK" || {
      ui_print "❌ [$ID] ติดตั้งล้มเหลว: $NAME"
      continue
    }
  else
    if [ "$ROOT_TYPE" = "magisk" ]; then
      magisk --install-module "$DEST" || {
        ui_print "❌ [$ID] ติดตั้งล้มเหลว: $NAME (Magisk)"
        continue
      }
    elif [ "$ROOT_TYPE" = "kernelsu" ]; then
      wait_for_boot_complete
      su -c "ksud module install \"$DEST\"" || {
        ui_print "❌ [$ID] ติดตั้งล้มเหลว: $NAME (KernelSU)"
        continue
      }
    else
      ui_print "❌ ไม่รู้จักระบบ Root → ข้าม $NAME"
      continue
    fi
  fi

  mkdir -p "$(dirname "$STATUS_FILE")"
  touch "$STATUS_FILE"
  COUNT_INSTALLED=$((COUNT_INSTALLED + 1))
done <<EOF

1.Zygisk-Next.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/1.Zygisk-Next.zip
2.Playintegrityfix.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/2.Playintegrityfix.zip
3.Tricky-Store.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/3.Tricky-Store.zip
4.LSPosed.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/4.LSPosed.zip
5.Shamiko.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/5.Shamiko.zip
6.Integrity-Box.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/6.Integrity-Box.zip
7.T-Target.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/7.T-Target.zip

EOF
#1.KsuWebUI.apk|https://raw.githubusercontent.com/sathapon-son/Module/main/KsuWebUI.apk
#9.Yuri.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/8.Yuri.zip
# สรุปผล
if [ "$COUNT_INSTALLED" -ge 7 ]; then
  mkdir -p "$(dirname "$FLAG_DONE")"
  touch "$FLAG_DONE"
  ui_print "🎉 ติดตั้งครบแล้ว → บันทึกสถานะเรียบร้อย"

  # Add these disable commands
  ui_print "⚙️ ปิดการใช้งานบริการระบบที่ไม่จำเป็น..."
  pm disable-user --user 0 com.wssyncmldm
  pm disable-user --user 0 com.sec.android.soagent
  pm disable-user --user 0 com.transsion.systemupdate
  pm disable-user --user 0 com.oplus.ota
  pm disable-user --user 0 com.oplus.ota  # Note: Duplicate line
  pm disable-user --user 0 com.fintech.life
  ui_print "✅ ปิดการใช้งานเรียบร้อยแล้ว"
else
  ui_print "📊 ติดตั้งสำเร็จทั้งหมด: $COUNT_INSTALLED/9"
fi

exit 0
