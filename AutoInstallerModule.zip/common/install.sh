#!/system/bin/sh

MODDIR=${0%/*}
STATUS_DIR="$MODDIR/status"
mkdir -p "$STATUS_DIR"

FLAG_DONE="$STATUS_DIR/.done"
if [ -f "$FLAG_DONE" ]; then
  ui_print "✅ ติดตั้งครบทุกโมดูลแล้ว → ข้ามการทำงาน"
  exit 0
fi

ui_print "📦 Preparing download..."

# ตรวจสอบคำสั่ง curl หรือ wget
if command -v curl >/dev/null 2>&1; then
  DL="curl -L -o"
elif command -v wget >/dev/null 2>&1; then
  DL="wget -O"
else
  ui_print "❌ ไม่พบคำสั่ง curl หรือ wget"
  exit 1
fi

mkdir -p /sdcard/Root

# เริ่มการดาวน์โหลดและติดตั้ง
COUNT_INSTALLED=0

while IFS="|" read -r NAME URL; do
  [ -z "$NAME" ] && continue
  [ -z "$URL" ] && continue

  ID=$(echo "$NAME" | cut -d. -f1)
  STATUS_FILE="$STATUS_DIR/$ID.installed"

  if [ -f "$STATUS_FILE" ]; then
    ui_print "✅ [$ID] $NAME - ติดตั้งแล้ว → ข้าม"
    COUNT_INSTALLED=$((COUNT_INSTALLED + 1))
    continue
  fi

  DEST="/sdcard/Root/$NAME"
  ui_print "⬇️ [$ID] กำลังดาวน์โหลด $NAME..."
  $DL "$DEST" "$URL" || {
    ui_print "❌ [$ID] ล้มเหลว: $NAME"
    continue
  }

  ui_print "📦 [$ID] ติดตั้ง $NAME..."
  if [ "${NAME##*.}" = "apk" ]; then
    TMP_APK="/data/local/tmp/$NAME"
    cp "$DEST" "$TMP_APK" || {
      ui_print "❌ [$ID] คัดลอก APK ล้มเหลว"
      continue
    }
    pm install -r "$TMP_APK" || {
      ui_print "❌ [$ID] ติดตั้งล้มเหลว: $NAME"
      continue
    }
  else
    magisk --install-module "$DEST" || {
      ui_print "❌ [$ID] ติดตั้งล้มเหลว: $NAME"
      continue
    }
  fi

  touch "$STATUS_FILE"
  COUNT_INSTALLED=$((COUNT_INSTALLED + 1))
done <<EOF
1.KsuWebUI.apk|https://raw.githubusercontent.com/sathapon-son/Module/main/KsuWebUI.apk
2.Zygisk-Next.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/1.Zygisk-Next.zip
3.Playintegrityfix.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/2.Playintegrityfix.zip
4.Tricky-Store.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/3.Tricky-Store.zip
5.LSPosed.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/4.LSPosed.zip
6.Shamiko.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/5.Shamiko.zip
7.Integrity-Box.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/6.Integrity-Box.zip
8.T-Target.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/7.T-Target.zip
9.Yuri.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/8.Yuri.zip
EOF

# ตรวจสอบว่าติดตั้งครบแล้วหรือยัง
if [ "$COUNT_INSTALLED" -ge 9 ]; then
  touch "$FLAG_DONE"
  ui_print "🎉 ติดตั้งครบแล้ว"

  # Add these disable commands
  ui_print "⚙️ ปิดการใช้งานบริการระบบที่ไม่จำเป็น..."
  pm disable-user --user 0 com.wssyncmldm
  pm disable-user --user 0 com.sec.android.soagent
  pm disable-user --user 0 com.transsion.systemupdate
  pm disable-user --user 0 com.oplus.ota
  pm disable-user --user 0 com.oplus.ota  # Note: Duplicate line
  pm disable-user --user 0 com.fintech.life
  ui_print "✅ ปิดการใช้งานเรียบร้อยแล้ว"
else
  ui_print "📊 ติดตั้งสำเร็จทั้งหมด: $COUNT_INSTALLED/9"
fi

exit 0
