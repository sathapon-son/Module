#!/system/bin/sh

MODDIR=${0%/*}
STATUS_DIR="$MODDIR/status"
mkdir -p "$STATUS_DIR"

FLAG_DONE="$STATUS_DIR/.done"
if [ -f "$FLAG_DONE" ]; then
  ui_print "✅ ติดตั้งครบทุกโมดูลแล้ว → ข้ามการทำงาน"
  exit 0
fi

ui_print "📦 Preparing download..."

# คำสั่งดาวน์โหลด
if command -v curl >/dev/null 2>&1; then
  DL="curl -L -o"
elif command -v wget >/dev/null 2>&1; then
  DL="wget -O"
else
  ui_print "❌ ไม่พบคำสั่ง curl หรือ wget"
  exit 1
fi

mkdir -p /sdcard/Root

# รายการชื่อไฟล์และลิงก์
COUNT_INSTALLED=0

while IFS="|" read -r NAME URL; do
  [ -z "$NAME" ] && continue
  [ -z "$URL" ] && continue

  ID=$(echo "$NAME" | cut -d. -f1)
  STATUS_FILE="$STATUS_DIR/$ID.installed"

  if [ -f "$STATUS_FILE" ]; then
    ui_print "✅ [$ID] $NAME - ติดตั้งแล้ว → ข้าม"
    COUNT_INSTALLED=$((COUNT_INSTALLED + 1))
    continue
  fi

  DEST="/sdcard/Root/$NAME"
  ui_print "⬇️ [$ID] กำลังดาวน์โหลด $NAME..."
  $DL "$DEST" "$URL" || {
    ui_print "❌ [$ID] ล้มเหลว: $NAME"
    continue
  }

  ui_print "📦 [$ID] ติดตั้ง $NAME..."
  magisk --install-module "$DEST" || {
    ui_print "❌ [$ID] ติดตั้งล้มเหลว: $NAME"
    continue
  }

  touch "$STATUS_FILE"
  COUNT_INSTALLED=$((COUNT_INSTALLED + 1))
done <<EOF
1.LSPosed.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/1.LSPosed.zip
2.Shamiko.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/2.Shamiko.zip
3.Tricky-Store.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/3.Tricky-Store.zip
4.T-Target.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/4.T-Target.zip
5.Integrity-Box.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/5.Integrity-Box.zip
6.PlayIntegrityFix.zip|https://raw.githubusercontent.com/sathapon-son/Module/main/6.PlayIntegrityFix.zip
EOF

# เช็กว่าครบ 6 ตัวหรือยัง
if [ "$COUNT_INSTALLED" -ge 6 ]; then
  touch "$FLAG_DONE"
  ui_print "🎉 ติดตั้งครบแล้ว → บันทึกสถานะเรียบร้อย"
else
  ui_print "📊 ติดตั้งสำเร็จทั้งหมด: $COUNT_INSTALLED/6"
fi

exit 0
