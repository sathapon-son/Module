#!/system/bin/sh

find /data/app -type f -name base.odex -delete