#!/bin/sh

# Magisk mount
SKIPMOUNT=false

# load system.prop
PROPFILE=true

# Flashing Interface
print_modname() {
 MODNAME=$(grep_prop name $TMPDIR/module.prop)
 MODVER=$(grep_prop version $TMPDIR/module.prop)
 DV=$(grep_prop author $TMPDIR/module.prop)
 Device=$(getprop ro.product.device)
 Model=$(getprop ro.product.model)
 Brand=$(getprop ro.product.brand)
 Time=$(date "+%d, %b - %H:%M %Z")

 echo "-------------------------------------"
 echo "✦ Author: $DV"
 echo "✦ Module: $MODNAME"
 echo "✦ Version: $MODVER"
 echo "✦ Kernel: $(uname -r)"
 sleep 0.5

 if [ "$BOOTMODE" ] && [ "$KSU" ]; then
 ui_print "✦ Provider: KernelSU app"
 sed -i "s/^des.*/description= [KernelSU is loaded] Enable ${MODNAME} /g" $MODPATH/module.prop
 ui_print "✦ KSU: $KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
 if [ "$(which magisk)" ]; then
  ui_print "*********************************************************"
  ui_print "! Multiple root implementation is NOT supported!"
  abort "*********************************************************"
 fi
 elif [ "$BOOTMODE" ] && [ "$MAGISK_VER_CODE" ]; then
 ui_print "✦ Provider: MAGISK😈" # Combine "Provider:" and "MAGISK😈"
 sed -i "s/^des.*/description= [💀 Magisk is loaded] Enable ${MODNAME} /g" $MODPATH/module.prop
 else
 ui_print "*********************************************************"
 ui_print "! Install from recovery is not supported"
 ui_print "! Please install from Magisk or KSU/APatch app"
 abort "*********************************************************"
 fi

 echo "-------------------------------------"
 echo "✦ Brand: $Brand"
 echo "✦ Device: $Device"
 echo "✦ Model: $Model"
 echo "✦ RAM: $(free | grep Mem | awk '{print $2}')"
 echo "-------------------------------------"
 echo "✦ Running $MODNAME"
 ui_print "✦ Script executed at $Time"
 echo "-------------------------------------"
 sleep 0.5

 # Check if target.txt exists
 if [ ! -f /data/adb/tricky_store/target.txt ]; then
 ui_print "*********************************************************"
 ui_print "✦ target.txt not found!"
 ui_print "✦ Please install tricky store module first"
 abort "*********************************************************"
 fi

 # Create the directory for target file if it doesn't exist
 ui_print "✦ Creating /data/adb/tricky_store"
 mkdir -p /data/adb/tricky_store

 # Remove the target.txt file if it exists
 ui_print "✦ Nuking target.txt from /data/adb/tricky_store"
 if [ -f /data/adb/tricky_store/target.txt ]; then
 rm /data/adb/tricky_store/target.txt
 fi

 # Add the default package names to the target file
 echo "✦ Adding default package names:"
 echo "com.google.android.gms" >> /data/adb/tricky_store/target.txt
 echo "io.github.vvb2060.keyattestation" >> /data/adb/tricky_store/target.txt
 echo "io.github.vvb2060.mahoshojo" >> /data/adb/tricky_store/target.txt
 echo "icu.nullptr.nativetest" >> /data/adb/tricky_store/target.txt
 sleep 1

 # Get all third-party app package names installed on device and add them to the target.txt file, appending a question mark to each package name.
 echo "✦ Retrieving all installed packages:"
 pm list packages | cut -d ":" -f 2 | sed 's/$/!'/ >> /data/adb/tricky_store/target.txt
 sleep 1

 # Display the result
 echo "✦ Here are the updated packages in target.txt:"
 sleep 1
 echo " "
 cat /data/adb/tricky_store/target.txt
 sleep 2

 on_install() {
 # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
 unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
 }
}

# end of file