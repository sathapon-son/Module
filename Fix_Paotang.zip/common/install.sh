#!/system/bin/sh

  ui_print "🧹 กำลัง Patch แอปเป๋าตัง..."
  adb shell su -c "find /data/app -path '*com.ktb.customer.qr*/oat/*/base.odex' -type f -delete"
  ui_print "✅ Patch แอปเป๋าตัง สำเร็จ"

exit 0
