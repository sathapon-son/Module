#!/system/bin/sh

if ! $BOOTMODE; then
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Recovery sucks"
    ui_print "! Please install from Magisk / KernelSU / APatch app"
    abort    "*********************************************************"
fi

if [ "$API" -lt 26 ]; then
    abort "! You can't use this module on Android < 8.0"
fi

check_zygisk() {
    local ZYGISK_MODULE="/data/adb/modules/zygisksu"
    local MAGISK_DIR="/data/adb/magisk"
    local ZYGISK_MSG="Zygisk is not enabled. Please enable it in Magisk settings or install ZygiskNext/ReZygisk module."

    if [ -d "$ZYGISK_MODULE" ]; then
        return 0
    fi

    # ✅ دعم ZygiskNext
    if [ -d "/data/adb/modules/zygisknext" ]; then
        ui_print "✅ ZygiskNext detected, continuing..."
        return 0
    fi

    # ✅ دعم ReZygisk
    if [ -d "/data/adb/modules/rezygisk" ]; then
        ui_print "✅ ReZygisk detected, continuing..."
        return 0
    fi

    if [ -d "$MAGISK_DIR" ]; then
        local ZYGISK_STATUS
        ZYGISK_STATUS=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';")
        if [ "$ZYGISK_STATUS" = "value=0" ]; then
            abort "$ZYGISK_MSG"
        fi
    else
        abort "$ZYGISK_MSG"
    fi
}

check_zygisk


[ -d "/data/adb/modules/safetynet-fix" ] && {
    ui_print "! safetynet-fix is incompatible and will be removed"
    touch "/data/adb/modules/safetynet-fix/remove"
}
[ -d "/data/adb/modules/playcurl" ] && ui_print "! ⚠️ playcurl may interfere"
[ -d "/data/adb/modules/MagiskHidePropsConf" ] && ui_print "! ⚠️ Obsolete MagiskHidePropsConf may cause issues"

if [ -f "/data/adb/pif.json" ]; then
    ui_print "- Backing up existing pif.json"
    mv -f /data/adb/pif.json /data/adb/pif.json.old
fi



chmod +x "$MODPATH/action.sh"
if [ -f "$MODPATH/action.sh" ]; then
    ui_print "▶️ Executing: action.sh..."
    sh "$MODPATH/action.sh" || abort "❌ Failed to run action.sh"
    ui_print "✅ action.sh executed."
else
    ui_print "⚠️ action.sh not found, skipping."
fi

# ══════════════════════════════════════

ui_print "╔════════════════════════════════════╗"
ui_print "║  ꧁𓆩🧠 𝑹𝒐𝒐𝒕 𝑷𝒉𝒂𝒏𝒕𝒐𝒎 𝑭𝑨𝑻𝑬𝑯 𓆪꧂     ║"
ui_print "║            ⟦ FATEH DZ ⟧            ║"
ui_print "║  🧠 Telegram: @ProfessorRoot_DZ     ║"
ui_print "║  🔗 Channel:  https://t.me/KARNELF  ║"
ui_print "╚════════════════════════════════════╝"
ui_print ""

device_model=$(getprop ro.product.model)
android_version=$(getprop ro.build.version.release)
api_level=$(getprop ro.build.version.sdk)

ui_print "📱 Device: $device_model"
ui_print "📦 Android: $android_version (API $api_level)"
ui_print ""

# ══════════════════════════════════════

keybox_file=$(find "$MODPATH" -type f -name "*ProfessorRoot_DZ" | head -n 1)
pif_integrity=$(find "$MODPATH" -type f -name "Reset.Play.Store.Services" | head -n 1)

if [ -z "$keybox_file" ] || [ -z "$pif_integrity" ]; then
    ui_print "❌ Required files not found!"
    [ -z "$keybox_file" ] && ui_print "  - ❌ Missing: ProfessorRoot_DZ"
    [ -z "$pif_integrity" ] && ui_print "  - ❌ Missing: Reset.Play.Store.Services"
    abort "❌ Aborting installation..."
fi

# ══════════════════════════════════════

if [ ! -d "/data/adb/tricky_store" ]; then
    mkdir -p /data/adb/tricky_store
    ui_print "📁 Created /data/adb/tricky_store/"
fi

if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
    mv -f "/data/adb/tricky_store/keybox.xml" "/data/adb/tricky_store/keybox.xml.bak"
    ui_print "📦 Backup: keybox.xml.bak"
fi

cp "$keybox_file" "/data/adb/tricky_store/keybox.xml"
chmod 644 /data/adb/tricky_store/keybox.xml

if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
    ui_print "✅ Keybox applied: $(basename "$keybox_file")"
else
    abort "❌ Failed to apply keybox.xml!"
fi

# ══════════════════════════════════════

chmod +x "$pif_integrity"
ui_print "▶️ Executing: $pif_integrity"
"$pif_integrity" || abort "❌ Failed to run Reset.Play.Store.Services"
ui_print "✅ Reset.Play.Store.Services executed."

# ══════════════════════════════════════

nohup am start -a android.intent.action.VIEW -d "https://t.me/kernelsu1" >/dev/null 2>&1 &
ui_print "📨 Opening Telegram Channel..."