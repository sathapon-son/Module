#!/system/bin/sh
MODDIR=${0%/*}
x01="/data/adb/modules/tricky_store"
x02="/data/adb/tricky_store"
x03="/data/adb/Integrity-Box-Logs"
x04="$x03/Installation.log"
x05="/data/adb/modules_update/integrity_box"
x07="$x05/Toaster.apk"
x09="$x02/target.txt"
x10="/data/adb/modules/playintegrityfix"
x11="$x10/module.prop"
x12="2025-06-06"
x13="$x02/security_patch.txt"
x16="$x02/tee_status"
x17="$x05/$x07"
x19="$x02/keybox.xml"
x20="$x02/keybox.xml.bak"
x25="$x02/.k"
x26="$x02/target.txt.bak"
x28="popup.toast"

i() {
    echo "$1" | tee -a "$x04"
}
 
mkdir -p $x03
touch $x03/Installation.log
touch "/sdcard/stop"
i " "

z() {
    am start -a android.intent.action.MAIN -e mona "$@" -n popup.toast/meow.helper.MainActivity > /dev/null
    sleep 0.5
}

if pm install "$x07" >/dev/null 2>&1; then
  z "Welcome to Alpha Installer"
else
  i "Toaster install failed."
fi

#Refresh the fp using PIF module 
i " "
if [ -d "$x10" ] && [ -f "$x11" ]; then
    if grep -q "name=Play Integrity Fix" "$x11"; then
        i " ✦ Adding Integrity Box's Fingerprint"
        cp $x05/pif.prop $x10
#        z "Custom Fingerprint has been updated"
    elif grep -q "name=Play Integrity Fork" "$x11"; then
        i " ✦ Adding Integrity Box's Fingerprint"
        cp $x05/pif.json $x10
#        z "Custom Fingerprint has been updated"
        
    fi
fi

# Tricky Store related functions
 if [ -d "$x01" ]; then
    i " ✦ Backing-up target list"

[ -s "$x09" ] && cp -f "$x09" "$x26"

i " ✦ Backing-up keybox"
[ -s "$x19" ] && cp -f "$x19" "$x20"

i " ✦ Updating keybox"
mv $x05/webroot/.hizru.tar $x19

i " ✦ Verifying keybox"
[ -s "$x19" ] || {
    i "  ❌ File not found or empty: $x19"
    exit 1
}

   sh $x05/webroot/common_scripts/user.sh > /dev/null 2>&1
   i " ✦ Updating Target list"
   
   if [ ! -f "$x13" ]; then
     i " ✦ Updating Boot Security Patch"
     echo "all=$x12" > "$x13"
   fi

 else
   i " ✦ Skipping TS related functions"
   i "  TrickyStore is not installed"
 fi

i " ✦ Smash The Action/WebUI After Rebooting"
i " "
i " "
i "         ••• Installation Completed ••• "
i " "
i " "
sleep 1
i "• WAIT WAIT WAIT"
i "• This is the Alpha version of Integrity Box"
i "• It doesn't require internet"
i "• It can work for months without any update"
sleep 4
i " "
i "• Smash the UPDATE KEYBOX button"
i "• From WebUI or Action menu"
i "• If the keybox gets banned"
sleep 3

exit 0
# End Of File