#!/system/bin/sh
set -eu

OUT_DIR="$(dirname "$0")/../json"
[ -d "$OUT_DIR" ] || mkdir -p "$OUT_DIR"
OUT="$OUT_DIR/device-info.json"

prop() { getprop "$1" 2>/dev/null | tr -d '\r'; }
has_su() {
  if command -v su >/dev/null 2>&1; then echo "Yes"; else echo "No"; fi
}

# Collect values
MANU="$(prop ro.product.manufacturer)"
BRAND="$(prop ro.product.brand)"
DEVICE="$(prop ro.product.device)"
MODEL="$(prop ro.product.model)"
ANDROID="$(prop ro.build.version.release)"
BID="$(prop ro.build.id)"
INC="$(prop ro.build.version.incremental)"
SP="$(prop ro.build.version.security_patch)"
FP="$(prop ro.build.fingerprint)"
KERNEL="$(uname -r 2>/dev/null | tr -d '\r')"
ROOT="$(has_su)"

# Fallbacks if empty
[ -n "$ANDROID" ] || ANDROID="$(prop ro.build.version.release_or_codename)"
[ -n "$MODEL" ] || MODEL="$(prop ro.product.odm.model)"

# Write JSON
cat > "$OUT" <<EOF
{
  "manufacturer": "${MANU:-}",
  "brand": "${BRAND:-}",
  "device": "${DEVICE:-}",
  "model": "${MODEL:-}",
  "android": "${ANDROID:-}",
  "build_id": "${BID:-}",
  "incremental": "${INC:-}",
  "security_patch": "${SP:-}",
  "fingerprint": "${FP:-}",
  "kernel": "${KERNEL:-}",
  "root": "${ROOT:-}"
}
EOF

exit 0
