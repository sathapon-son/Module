(function(){
  const $  = (s,r=document)=>r.querySelector(s);
  const $$ = (s,r=document)=>Array.from(r.querySelectorAll(s));
  const toasts = $('#toast-container') || (function(){ const d=document.createElement('div'); d.id='toast-container'; document.body.appendChild(d); return d; })();
  function toast(msg, ms=1600){
    const t=document.createElement('div'); t.className='toast'; t.textContent=msg;
    t.addEventListener('click',()=>t.remove()); toasts.appendChild(t);
    setTimeout(()=>t.remove(), Math.max(ms, 1800)+800);
  }

  // ---- Language (JSON + fallback) ----

  function S(k, fallback){
    try{ return (typeof L==='object' && L && L[k]) ? L[k] : (fallback||''); }catch(_){ return fallback||''; }
  }


    // Normalize legacy keys to new i18n keys
    function T(k, fallback){ try{ return (L && (L[k] || L['t_'+k])) || fallback || ''; }catch(_){ return fallback||''; } }

  const FALLBACK = {
    ar:{ home_title:"📜 الصفحة الرئيسية", settings_title:"⚙️ الإعدادات", devinfo_title:"معلومات الجهاز", links_title:"روابط",
         k_manu:"الشركة", k_brand:"العلامة", k_device:"الجهاز", k_model:"الطراز", k_android:"أندرويد",
         k_bid:"معرّف البناء", k_inc:"الإصدار", k_sp:"الحزمة الأمنية", k_fp:"بصمة البناء", k_kernel:"النواة", k_root:"الروت",
         nav_home:"الرئيسية", nav_settings:"الإعدادات", btn_refresh:"تحديث المعلومات",
         act_update_keybox:"Update keybox", act_pif2:"pif2", act_target_txt:"target_txt", act_boot_hash:"boot_hash",
         act_kill_google:"kill_google_process", act_security_patch:"security_patch", act_odex_clean:"odex_clean",
         act_del_twrp:"Delete_TWRP_Folder", act_hma_clean:"hma_clean",
         run:"⏳ جاري التنفيذ...", done:"✅ تم التنفيذ", fail:"⚠️ فشل التنفيذ",
         info_start:"⏳ تحديث معلومات الجهاز...", info_ok:"✅ تم التحديث", info_fail:"⚠️ تعذر التحديث" , t_run:'⏳ جاري التنفيذ...', t_done:'✅ تم التنفيذ', t_fail:'⚠️ فشل التنفيذ', t_info_start:'⏳ تحديث معلومات الجهاز...', t_info_ok:'✅ تم التحديث', t_info_fail:'⚠️ تعذر التحديث', t_link_open:'📲 فتح الرابط', t_browser_open:'🌐 فتح المتصفح', t_link_copied:'🔗 نُسخ الرابط — افتحه يدويًا' },
    en:{ home_title:"📜 Home", settings_title:"⚙️ Settings", devinfo_title:"Device Info", links_title:"Links",
         k_manu:"Manufacturer", k_brand:"Brand", k_device:"Device", k_model:"Model", k_android:"Android",
         k_bid:"Build ID", k_inc:"Incremental", k_sp:"Security Patch", k_fp:"Build Fingerprint", k_kernel:"Kernel", k_root:"Root",
         nav_home:"Home", nav_settings:"Settings", btn_refresh:"Refresh Info",
         act_update_keybox:"Update keybox", act_pif2:"pif2", act_target_txt:"target_txt", act_boot_hash:"boot_hash",
         act_kill_google:"kill_google_process", act_security_patch:"security_patch", act_odex_clean:"odex_clean",
         act_del_twrp:"Delete_TWRP_Folder", act_hma_clean:"hma_clean",
         run:"⏳ Running...", done:"✅ Done", fail:"⚠️ Failed",
         info_start:"⏳ Updating device info...", info_ok:"✅ Updated", info_fail:"⚠️ Update failed" },
    hi:{ home_title:"📜 होम", settings_title:"⚙️ सेटिंग्स", devinfo_title:"डिवाइस जानकारी", links_title:"लिंक",
         k_manu:"निर्माता", k_brand:"ब्रांड", k_device:"डिवाइस", k_model:"मॉडल", k_android:"एंड्रॉइड",
         k_bid:"बिल्ड आईडी", k_inc:"इन्क्रिमेंटल", k_sp:"सिक्योरिटी पैच", k_fp:"फिंगरप्रिंट", k_kernel:"कर्नेल", k_root:"रूट",
         nav_home:"होम", nav_settings:"सेटिंग्स", btn_refresh:"जानकारी अपडेट",
         act_update_keybox:"Update keybox", act_pif2:"pif2", act_target_txt:"target_txt", act_boot_hash:"boot_hash",
         act_kill_google:"kill_google_process", act_security_patch:"security_patch", act_odex_clean:"odex_clean",
         act_del_twrp:"Delete_TWRP_Folder", act_hma_clean:"hma_clean",
         run:"⏳ चल रहा है...", done:"✅ पूरा", fail:"⚠️ विफल",
         info_start:"⏳ डिवाइस जानकारी अपडेट...", info_ok:"✅ अपडेट हो गया", info_fail:"⚠️ अपडेट विफल" },
    zh:{ home_title:"📜 首页", settings_title:"⚙️ 设置", devinfo_title:"设备信息", links_title:"链接",
         k_manu:"制造商", k_brand:"品牌", k_device:"设备", k_model:"型号", k_android:"安卓",
         k_bid:"构建ID", k_inc:"增量版本", k_sp:"安全补丁", k_fp:"构建指纹", k_kernel:"内核", k_root:"Root",
         nav_home:"首页", nav_settings:"设置", btn_refresh:"刷新信息",
         act_update_keybox:"Update keybox", act_pif2:"pif2", act_target_txt:"target_txt", act_boot_hash:"boot_hash",
         act_kill_google:"kill_google_process", act_security_patch:"security_patch", act_odex_clean:"odex_clean",
         act_del_twrp:"Delete_TWRP_Folder", act_hma_clean:"hma_clean",
         run:"⏳ 正在执行…", done:"✅ 完成", fail:"⚠️ 失败",
         info_start:"⏳ 更新设备信息…", info_ok:"✅ 已更新", info_fail:"⚠️ 更新失败" },
  };
  let L = FALLBACK.ar;

  function applyI18N(dict){
    $$('[data-i18n]').forEach(el=>{
      const key=el.getAttribute('data-i18n');
      if (dict[key]) el.textContent = dict[key];
    });
    // direction
    const lang = localStorage.getItem('rf_lang') || 'ar';
    document.documentElement.lang = lang==='zh'?'zh':(lang==='hi'?'hi':(lang==='en'?'en':'ar'));
    document.documentElement.dir = (lang==='ar'?'rtl':'ltr');
  }

  function loadLang(lang){
    localStorage.setItem('rf_lang', lang);
    // try fetch json
    fetch('lang/'+lang+'.json?ts='+Date.now()).then(r=>{
      if(!r.ok) throw 0; return r.json();
    }).then(dict=>{
      L = dict || FALLBACK[lang] || FALLBACK.ar;
      applyI18N(L);
      toast('✅ Language set');
    }).catch(()=>{
      L = FALLBACK[lang] || FALLBACK.ar;
      applyI18N(L);
      toast('✅ Language set (fallback)');
    });
  }

  // menu button
  $('#lang-btn')?.addEventListener('click',(e)=>{
    e.stopPropagation(); const m=$('#lang-menu');
    m.style.display=(m.style.display==='flex')?'none':'flex'; m.style.flexDirection='column';
  });
  $('#lang-menu')?.querySelectorAll('button').forEach(b=> b.addEventListener('click', ()=> loadLang(b.dataset.lang) ));
  document.addEventListener('click',()=>{ const m=$('#lang-menu'); if(m) m.style.display='none'; });

  // ---- Bridge / Exec ----
  function bridge(){
    if (typeof ksu==='object' && typeof ksu.exec==='function') return 'ksu';
    if (typeof Android==='object' && typeof Android.runShellCommand==='function') return 'android';
    return 'none';
  }
  function execShell(cmd, cb){
    const t=bridge()
    if (t==='ksu'){
      try{ ksu.exec(cmd,"{}",(c,o,e)=>cb(c,o,e)); }
      catch(_){ const id='cb'+Date.now(); window[id]=(c,o,e)=>{delete window[id]; cb(c,o,e)}; ksu.exec(cmd,"{}",id); }
    } else if (t==='android'){
      try{ const out=Android.runShellCommand(cmd); cb(0,String(out||''),''); }catch(e){ cb(1,'',String(e)); }
    } else { cb(127,'','bridge-missing'); }
  }

  // ---- Nav ----
  $$('.bottom-nav .nav-btn').forEach(btn=>{
    btn.addEventListener('click',()=>{
      $$('.bottom-nav .nav-btn').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      const tgt = btn.getAttribute('data-target');
      $$('.page').forEach(p=>p.classList.remove('active'));
      $('#'+tgt)?.classList.add('active');
      if (tgt==='settings-page') setTimeout(refreshDeviceInfo2, 150);
    });
  });

  // ---- Actions (9 buttons) ----
  const BIN="/data/adb/modules/playintegrityfix/bin";
  const BIN_UPD="/data/adb/modules_update/playintegrityfix/bin";
  function runAction(name){
    // i18n toasts
    toast(S('t_run','⏳ Running…'));
    let finished = false;
    const doneTimer = setTimeout(()=>{ if(!finished){ toast(S('t_done','✅ Done')); } }, 5000);

    const BIN="/data/adb/modules/playintegrityfix/bin";
    const BIN_UPD="/data/adb/modules_update/playintegrityfix/bin";
    const cmd = `A='${BIN_UPD}/${name}.sh'; B='${BIN}/${name}.sh'; if [ -f "$A" ]; then chmod 0755 "$A" 2>/dev/null; sh "$A"; else chmod 0755 "$B" 2>/dev/null; sh "$B"; fi`;
    execShell(cmd,(rc)=>{
      if (rc!==0){
        if(!finished){ finished = true; clearTimeout(doneTimer); }
        toast(S('t_fail','⚠️ Failed'));
      }
    });
  } }, 5000);
    const cmd = `A='${BIN_UPD}/${name}.sh'; B='${BIN}/${name}.sh'; if [ -f "$A" ]; then chmod 0755 "$A" 2>/dev/null; sh "$A"; else chmod 0755 "$B" 2>/dev/null; sh "$B"; fi`;
    execShell(cmd,(rc,o,e)=>{ if(rc===0){ toast(T('done', '✅ Done'))} else { toast(L.fail+ ' rc='+rc); }
      if (rc!==0){ if(!finished){ clearTimeout(T); finished=true; setTimeout(()=> toast(T('fail', '⚠️ Failed')), 5000);} }
    });
  }
  function bindActions(){
    $$('.menu-btn[data-script]').forEach(b=> b.addEventListener('click', ()=>{
      const s=b.getAttribute('data-script'); if(!s) return; runAction(s.replace(/\.sh$/,''));
    }));
  }

  // ---- External links ----
  function openUrlSmart(url){
    // Try as app context first (works better than pure root)
    const cmdApp = `su -lp 2000 -c "am start -a android.intent.action.VIEW -d '${url}'"`;
    execShell(cmdApp,(rc1)=>{
      if (rc1===0){ toast(T('link_open','📲 Opening link')); return; }
      // Try as root (بعض الأنظمة تسمح)
      const cmdRoot = `am start -a android.intent.action.VIEW -d '${url}'`;
      execShell(cmdRoot,(rc2)=>{
        if (rc2===0){ toast(T('link_open','📲 Opening link')); return; }
        // Try web fallback
        try{ window.open(url, '_blank'); toast(T('browser_open','🌐 Opening browser')); }
        catch(_){
          // As a last resort: copy to clipboard
          try{ navigator.clipboard.writeText(url).then(()=>toast('🔗 نُسخ الرابط — افتحه يدويًا')); }
          catch(e){ toast('⚠️ تعذّر فتح الرابط'); }
        }
      });
    });
  }
  $$('.update-link, .link[data-url]').forEach(b=>{
    const url=b.getAttribute('data-url'); if(!url) return;
    b.addEventListener('click',()=> openUrlSmart(url));
  });

// ---- Device Info ----


  // Prefer-fetch version (v2)
  
async function fetchJsonTry(paths){
  for (const p of paths){
    try{
      const r = await fetch(p + (p.includes('?')?'':'?t='+Date.now()), {cache:'no-store'});
      if(!r.ok) { continue; }
      const d = await r.json();
      return d;
    }catch(e){ /* try next */ }
  }
  throw new Error('all paths failed');
}

async function refreshDeviceInfo2(){
  try{
    const url = (window.DEVINFO_URL || 'json/device-info.json') + '?t=' + Date.now();
    const r = await fetch(url, {cache:'no-store'});
    const d = await r.json();
    // Debug: show what's read
    try{ toast('📄 ' + (d.device||'-') + ' • ' + (d.android||'-')); }catch(_){}
    // Hard-set once immediately
    try{
      var E = (id,v)=>{ var e=document.getElementById(id); if(e){ bridge() return true;} return false; };
      E('dn-device', d.device);
      E('dn-devices', d.devices||d.device);
      E('dn-android', d.android);
      E('dn-kernel', d.kernel);
      E('dn-root', d.root);
      E('dn-sp', d.security_patch);
    }catch(_){}
    // Call fillDevice as well
    try{ fillDevice(d); __orderFill(d); }catch(_){}
    // Retry after 400ms in case another code overwrote values
    setTimeout(function(){ try{
      var E = (id,v)=>{ var e=document.getElementById(id); if(e){ bridge() return true;} return false; };
      E('dn-device', d.device);
      E('dn-devices', d.devices||d.device);
      E('dn-android', d.android);
      E('dn-kernel', d.kernel);
      E('dn-root', d.root);
      E('dn-sp', d.security_patch);
    }catch(_){ } }, 400);
    __diagIds(); try{ toast('✅ Done'); }catch(_){}
  }catch(e){
    try{ toast('⚠️ Failed: ' + (e && e.message ? e.message : 'read error')); }catch(_){}
  }
}
);
    const d = await r.json();
    fillDevice({
      device: d.device || '-',
      devices: d.devices || d.device || '-',
      android: d.android || '-',
      kernel: d.kernel || '-',
      root: d.root || '-',
      security_patch: d.security_patch || '-'
    });
    
window.__lastDevInfo = d;
__diagIds(); try{ toast('✅ Done'); }catch(_){}
  }catch(e){
    try{ toast('⚠️ Failed: ' + (e && e.message ? e.message : 'read error')); }catch(_){}
  }
}
);
    const d = await r.json();
    fillDevice({
      device: d.device || '-',
      devices: d.devices || d.device || '-',
      android: d.android || '-',
      kernel: d.kernel || '-',
      root: d.root || '-',
      security_patch: d.security_patch || '-'
    });
    __diagIds(); try{ toast('✅ Done'); }catch(_){}
  }catch(e){
    try{ toast('⚠️ Failed: ' + (e && e.message ? e.message : 'read error')); }catch(_){}
  }
};
    fillDevice(d); __orderFill(d); __diagIds(); try{ toast('✅ Done'); }catch(_){}
  }catch(e){
    try{ toast('⚠️ Failed to read JSON: ' + (e && e.message ? e.message : e)); }catch(_){}
  }
}
)
      .catch(()=>{ 
        // fallback to original bridge-based logic
        (function(){
          const MOD_BASE="/data/adb/modules/playintegrityfix";
          const MOD_UPD="/data/adb/modules_update/playintegrityfix";
          const JSON_REL="webroot/json/device-info.json";
          const SH_REL="webroot/common/device-info.sh";
          function catJSON(cb){
            const cmd=`if [ -f '${MOD_UPD}/${JSON_REL}' ]; then cat '${MOD_UPD}/${JSON_REL}';
                       elif [ -f '${MOD_BASE}/${JSON_REL}' ]; then cat '${MOD_BASE}/${JSON_REL}';
                       else exit 2; fi`;
            execShell(cmd,(rc,out)=> cb(rc, out?String(out).trim():''));
          }
          function runWriterThenRead(cb){
            const runCmd=\`A='${MOD_UPD}/${SH_REL}'; B='${MOD_BASE}/${SH_REL}';
                         if [ -f "$A" ]; then chmod 0755 "$A"; sh "$A";
                         elif [ -f "$B" ]; then chmod 0755 "$B"; sh "$B";
                         else exit 9; fi\`;
            execShell(runCmd, ()=> setTimeout(()=> catJSON(cb), 200));
          }
          catJSON((rc,out)=>{
            if (rc===0 && out.startsWith('{')){
              try{ fillDevice(JSON.parse(out)); return toast(T('info_ok','✅ Done')); }catch(e){}
            }
            runWriterThenRead((rc2,out2)=>{
              if (rc2===0 && out2 && out2.startsWith('{')){
                try{ fillDevice(JSON.parse(out2)); return toast(T('info_ok','✅ Done')); }catch(e){ return toast(T('info_fail','⚠️ Failed')); }
              }
              toast(T('info_fail','⚠️ Failed'));
            });
          });
        })();
      });
  }

  const MOD_BASE="/data/adb/modules/playintegrityfix";
  const MOD_UPD="/data/adb/modules_update/playintegrityfix";
  const JSON_REL="webroot/json/device-info.json";
  const SH_REL="webroot/common/device-info.sh";

  function fillDevice(d){
  const val = x => (x!==undefined && x!==null && String(x).trim()) || '—';
  __setByIdOrLabel([
    {id:'dn-device',  key:'k_device',  text:'Device',         value: val(d.device)},
    {id:'dn-devices', key:'k_devices', text:'Devices',        value: val(d.devices || d.device)},
    {id:'dn-android', key:'k_android', text:'Android',        value: val(d.android)},
    {id:'dn-kernel',  key:'k_kernel',  text:'Kernel',         value: val(d.kernel)},
    {id:'dn-root',    key:'k_root',    text:'Root',           value: val(d.root)},
    {id:'dn-sp',      key:'k_sp',      text:'Security Patch', value: val(d.security_patch)}
  ]);
};
  set('#dn-device', d.device);
  set('#dn-devices', d.devices || d.device);
  set('#dn-android', d.android);
  set('#dn-kernel', d.kernel);
  set('#dn-root', d.root);
  set('#dn-sp', d.security_patch);
}
};
  set('#dn-device', d.device);
  set('#dn-devices', d.devices || d.device);
  set('#dn-android', d.android);
  set('#dn-kernel', d.kernel);
  set('#dn-root', d.root);
  set('#dn-sp', d.security_patch);
};
  set('#dn-device', d.device);
  set('#dn-devices', d.devices || d.device);
  set('#dn-android', d.android);
  set('#dn-kernel', d.kernel);
  set('#dn-root', d.root);
  set('#dn-sp', d.security_patch);
};
  set('#dn-device', d.device);
  set('#dn-devices', d.devices);
  set('#dn-android', d.android);
  set('#dn-kernel', d.kernel);
  set('#dn-root', d.root);
  set('#dn-sp', d.security_patch);
};
  set('#dn-device', d.device);
  set('#dn-devices', d.devices);
  set('#dn-root', d.root);
  set('#dn-kernel', d.kernel);
  set('#dn-android', d.android);
  set('#dn-sp', d.security_patch);
};
  // Only the fields we keep:
  set('#dn-device', d.device);
  set('#dn-root', d.root);
  set('#dn-kernel', d.kernel);
  set('#dn-android', d.android);
  set('#dn-sp', d.security_patch);
};
  set('#dn-device', d.device);
  set('#dn-root', d.root);
  set('#dn-kernel', d.kernel);
  set('#dn-android', d.android);
  set('#dn-sp', d.security_patch);
};
    set('#dev-manu',d.manufacturer); set('#dev-brand',d.brand); set('#dev-device',d.device); set('#dev-model',d.model);
    set('#dev-android',d.android); set('#dev-bid',d.build_id); set('#dev-inc',d.incremental); set('#dev-sp',d.security_patch);
    set('#dev-fp',d.fingerprint); set('#dev-kernel',d.kernel); set('#dev-root',d.root);
  }
  function catJSON(cb){
    const cmd=`if [ -f '${MOD_UPD}/${JSON_REL}' ]; then cat '${MOD_UPD}/${JSON_REL}';
               elif [ -f '${MOD_BASE}/${JSON_REL}' ]; then cat '${MOD_BASE}/${JSON_REL}';
               else exit 2; fi`;
    execShell(cmd,(rc,out)=> cb(rc, out?out.trim():''));
  }
  function runWriterThenRead(cb){
    const runCmd=`A='${MOD_UPD}/${SH_REL}'; B='${MOD_BASE}/${SH_REL}';
                 if [ -f "$A" ]; then chmod 0755 "$A"; sh "$A";
                 elif [ -f "$B" ]; then chmod 0755 "$B"; sh "$B";
                 else exit 9; fi`;
    execShell(runCmd, ()=> setTimeout(()=> catJSON(cb), 200));
  }
  function refreshDeviceInfo(){
    if (bridge()==='none'){
      // Pure-web fallback: try to fetch the JSON file directly
      fetch('json/device-info.json?ts='+Date.now())
        .then(r=>r.ok?r.json():Promise.reject())
        .then(d=>{ fillDevice(d); __orderFill(d); toast(T('info_ok','✅ Done')); })
        .catch(()=> toast(L.info_fail));
      return;
    }
    toast(T('info_start','⏳ ...'))
    catJSON((rc,out)=>{
      if (rc===0 && out.startsWith('{')){
        try{ fillDevice(JSON.parse(out)); return toast(T('info_ok','✅ Done')); }catch{}
      }
      runWriterThenRead((rc2,out2)=>{
        if (rc2===0 && out2 && out2.startsWith('{')){
          try{ fillDevice(JSON.parse(out2)); return toast(T('info_ok','✅ Done')); }catch{return toast(T('info_fail','⚠️ Failed'));}
        }
        toast(T('info_fail','⚠️ Failed'));
      });
    });
  }
  $('#refresh-info-btn')?.addEventListener('click', refreshDeviceInfo2);

  // ---- init ----
  document.addEventListener('DOMContentLoaded', ()=>{
    bindActions(); toast('bridge:'+bridge());
    const saved = localStorage.getItem('rf_lang') || 'ar';
    // load dict for saved language
    fetch('lang/'+saved+'.json?ts='+Date.now()).then(r=>r.ok?r.json():Promise.reject())
      .then(d=>{ L=d; applyI18N(L); })
      .catch(()=>{ L = FALLBACK[saved]||FALLBACK.ar; applyI18N(L); });
  });
})();

function __diagIds(){
  var ids=['dn-device','dn-devices','dn-android','dn-kernel','dn-root','dn-sp'];
  var found=[], missing=[];
  ids.forEach(id=>{ var el=document.getElementById(id); if(el){ found.push(id); el.classList.add('diag-flash'); setTimeout(()=>el.classList.remove('diag-flash'), 1200);} else { missing.push(id); } });
  try{ toast('🔎 found: '+found.join(', ')+' | missing: '+missing.join(', ')); }catch(_){}
}



function __orderFill(d){
  try{
    var card = document.querySelector('.info-card .card-content') || document.querySelector('.info-card');
    if(!card) return;
    var slots = [];
    // collect nodes that are just a dash "—" (common in our layout)
    var all = card.querySelectorAll('*');
    for (var i=0;i<all.length;i++){
      var t = (all[i].textContent||'').trim();
      if (t==='—') slots.push(all[i]);
    }
    var vals=[d.device, d.devices||d.device, d.android, d.kernel, d.root, d.security_patch];
    for (var j=0;j<Math.min(slots.length, vals.length); j++){
      if(slots[j]) slots[j].textContent = (vals[j] && String(vals[j]).trim()) || '—';
    }
  }catch(_){}
}


window.__lastDevInfo = null;

function showDevDebug(){
  try{
    var d = window.__lastDevInfo;
    var txt = d ? JSON.stringify(d, null, 2) : 'No data yet';
    var el = document.getElementById('devdebug');
    if(!el){
      el = document.createElement('pre');
      el.id = 'devdebug';
      el.className = 'devdebug';
      document.body.appendChild(el);
    }
    el.textContent = txt;
    el.style.display = 'block';
    setTimeout(()=>{ el.style.display='none'; }, 4000);
  }catch(_){}
}


function __setByIdOrLabel(map){
  // map = {id:'dn-device', key:'k_device', text:'Device', value:'POCO ...'}
  function setText(el, v){ if(el){ el.textContent = (v && String(v).trim()) || '—'; return true; } return false; }
  for (const m of map){
    // 1) Try by ID
    if (m.id && setText(document.getElementById(m.id), m.value)) continue;
    // 2) Try by data-i18n on label .k inside kv-pill
    var pills = document.querySelectorAll('.kv-pill');
    var done = false;
    pills.forEach(p=>{
      if(done) return;
      var k = p.querySelector('.k');
      var v = p.querySelector('.v');
      if(!k || !v) return;
      var key = (k.getAttribute('data-i18n')||'').trim();
      var txt = (k.textContent||'').trim().toLowerCase();
      if ((m.key && key===m.key) || (m.text && txt===m.text.toLowerCase())){
        if (setText(v, m.value)) done = true;
      }
    });
  }
}



/* v16.21 normalize IDs based on label text in multiple languages */
function normalizeKvIds(){
  try{
    var map = {
      'dn-device':  ['device','الجهاز','الجهازُ','उपकरण','डिवाइस','设备'],
      'dn-devices': ['devices','الأجهزة','الأجهزةُ','डिवाइसेज़','设备(复数)'],
      'dn-android': ['android','أندرويد','اندرويد','एंड्रॉयड','安卓'],
      'dn-kernel':  ['kernel','النواة','نواة','कर्नेल','内核'],
      'dn-root':    ['root','الروت','روت','रूट','Root'],
      'dn-sp':      ['security patch','الحزمة الأمنية','التصحيح الأمني','सिक्योरिटी पैच','安全补丁']
    };
    var pills = document.querySelectorAll('.kv-pill');
    var assigned = [];
    pills.forEach(function(p){
      var k = p.querySelector('.k'); var v = p.querySelector('.v');
      if(!k||!v) return;
      var txt = (k.textContent||'').trim().toLowerCase();
      for (var id in map){
        var list = map[id];
        for (var i=0;i<list.length;i++){
          if (txt === list[i].toLowerCase()){
            v.id = id; // assign our expected id to the value element
            assigned.push(id);
            break;
          }
        }
      }
    });
    try{ toast('🔧 mapped: '+assigned.join(', ')); }catch(_){}
  }catch(e){ try{ toast('mapErr '+e.message); }catch(_){ } }
}

