// device-info-fix v16.final
(function(){
  // Safe toast
  function toastSafe(m){ try{ if (window.toast) toast(m); }catch(_){} }

  // Labels in multiple languages
  const LABELS_MAP = {
    device:  ['Device','الجهاز','الجهازُ','उपकरण','डिवाइस','设备'],
    devices: ['Devices','الأجهزة','الأجهزةُ','डिवाइसेज़','设备(复数)'],
    android: ['Android','أندرويد','اندرويد','एंड्रॉयड','安卓'],
    kernel:  ['Kernel','النواة','نواة','कर्नेल','内核'],
    root:    ['Root','الروت','روت','रूट','Root'],
    sp:      ['Security Patch','الحزمة الأمنية','التصحيح الأمني','सिक्योरिटी पैच','安全补丁']
  };

  function findValueElByLabel(keys){
    const pills = document.querySelectorAll('.kv-pill');
    for (const p of pills){
      const k = p.querySelector('.k');
      const v = p.querySelector('.v');
      if (!k || !v) continue;
      const txt = (k.textContent||'').trim().toLowerCase();
      for (const key of keys){
        if (txt === key.toLowerCase()) return v;
      }
    }
    return null;
  }
  function setByLabel(labelKey, value){
    const el = findValueElByLabel(LABELS_MAP[labelKey] || []);
    if (el){ el.textContent = (value && String(value).trim()) || '—'; return true; }
    return false;
  }

  function normalizeKvIds(){
    try{
      const map = {
        'dn-device':  ['device','الجهاز','الجهازُ','उपकरण','डिवाइस','设备'],
        'dn-devices': ['devices','الأجهزة','الأجهزةُ','डिवाइसेज़','设备(复数)'],
        'dn-android': ['android','أندرويد','اندرويد','एंड्रॉयड','安卓'],
        'dn-kernel':  ['kernel','النواة','نواة','कर्नेल','内核'],
        'dn-root':    ['root','الروت','روت','रूट','Root'],
        'dn-sp':      ['security patch','الحزمة الأمنية','التصحيح الأمني','सिक्योरिटी पैच','安全补丁']
      };
      document.querySelectorAll('.kv-pill').forEach(p=>{
        const k = p.querySelector('.k'), v = p.querySelector('.v');
        if(!k||!v) return;
        const t = (k.textContent||'').trim().toLowerCase();
        for (const id in map){
          if (map[id].some(x=>t===x.toLowerCase())){ v.id = id; break; }
        }
      });
    }catch(_){}
  }

  function fillDevicePatched(d){
    setByLabel('device',  d.device);
    setByLabel('devices', d.devices || d.device);
    setByLabel('android', d.android);
    setByLabel('kernel',  d.kernel);
    setByLabel('root',    d.root);
    setByLabel('sp',      d.security_patch);
  }

  async function refreshPatched(){
    try{
      const url = (window.DEVINFO_URL || 'json/device-info.json') + '?t=' + Date.now();
      const r = await fetch(url, {cache:'no-store'});
      const d = await r.json();
      fillDevicePatched(d);
      setTimeout(()=>fillDevicePatched(d), 300);
      setTimeout(()=>fillDevicePatched(d), 800);
      toastSafe('✅ تم التحديث');
    }catch(e){
      toastSafe('⚠️ فشل التحديث');
    }
  }

  // Expose / override safely
  window.fillDevice = fillDevicePatched;
  window.refreshDeviceInfo2 = refreshPatched;

  document.addEventListener('DOMContentLoaded', function(){
    normalizeKvIds();
    const btn = document.getElementById('refresh-info-btn');
    if (btn && !btn.__rf_bound){
      btn.__rf_bound = true;
      btn.onclick = refreshPatched;
    }
  });
})();
