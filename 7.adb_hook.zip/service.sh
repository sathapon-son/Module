#!/system/bin/sh
sleep 10
settings put global adb_enabled 2
